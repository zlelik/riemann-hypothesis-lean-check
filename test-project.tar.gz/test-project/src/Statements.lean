import Mathlib.Data.Real.Basic
import Mathlib.Analysis.Complex.Trigonometric

/-!
# Statement of the test project

The test project proves one statement: for every real number `x`, `sin x ^ 2 + cos x ^ 2 = 1`.

It is built like the Riemann Hypothesis project: this file states the claim as a definition,
and `Main.lean` contains the main theorem, which proves that definition.
-/

/-- For every real number `x`: `sin x ^ 2 + cos x ^ 2 = 1`. -/
def SinSqAddCosSq : Prop :=
  ∀ x : ℝ, Real.sin x ^ 2 + Real.cos x ^ 2 = 1
