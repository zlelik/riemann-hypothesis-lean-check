import Statements
import Lemmata

/-!
# Main theorem of the test project

`run-checks.sh` checks this theorem: the axioms it uses, its exact statement, and its proof with
Lean's kernel and with two other kernels, nanoda and Lean4Lean.
-/

/-- The main theorem: the statement `SinSqAddCosSq` from `Statements.lean` is true. -/
theorem sin_sq_add_cos_sq_eq_one : SinSqAddCosSq :=
  sin_sq_add_cos_sq_of_steps
