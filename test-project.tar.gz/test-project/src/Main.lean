import Statements
import Lemmata

/-!
# Main theorem of the test project

`run-checks.sh` checks this theorem: the axioms it uses (step 2.5), its exact statement
(step 2.6), and its proof with Lean's kernel and with two independent kernels (steps 2.8 to 2.11).
-/

/-- The main theorem: the statement `SinSqAddCosSq` from `Statements.lean` is true. -/
theorem sin_sq_add_cos_sq_eq_one : SinSqAddCosSq :=
  sin_sq_add_cos_sq_of_steps
