import Mathlib.Algebra.Group.Defs
import Mathlib.Data.Real.Basic
import Mathlib.Analysis.Complex.Trigonometric
import Mathlib.Tactic.Ring

/-!
# Proof steps of the test project

The proof uses two facts from Mathlib:

* `Real.cos_sub`: `cos (x - y) = cos x * cos y + sin x * sin y` for all real numbers `x`, `y`;
* `Real.cos_zero`: `cos 0 = 1`.
-/

/-- Step 1: `cos (x - x) = 1`, because `x - x = 0` and `cos 0 = 1`. -/
theorem cos_sub_self_eq_one (x : ℝ) : Real.cos (x - x) = 1 := by
  rw [sub_self, Real.cos_zero]

/-- Step 2: the formula for `cos (x - y)`, with `y = x`. -/
theorem cos_sub_self_eq (x : ℝ) :
    Real.cos (x - x) = Real.cos x * Real.cos x + Real.sin x * Real.sin x :=
  Real.cos_sub x x

/-- Step 3: steps 1 and 2 together give `sin x ^ 2 + cos x ^ 2 = 1`. -/
theorem sin_sq_add_cos_sq_of_steps (x : ℝ) : Real.sin x ^ 2 + Real.cos x ^ 2 = 1 :=
  calc
    Real.sin x ^ 2 + Real.cos x ^ 2 = Real.cos x * Real.cos x + Real.sin x * Real.sin x := by ring
    _ = Real.cos (x - x) := (cos_sub_self_eq x).symm
    _ = 1 := cos_sub_self_eq_one x
